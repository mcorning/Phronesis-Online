---
layout: default
title: The Phronesis Project
---


## The Phronesis Project
![alt text](</images/phronesis_logo_128.png>)

**A nonprofit initiative for ethical technology and civic education.** See our [Mission Statement](/pages/mission-statement/) justifying our first four Projects.


[Agora](/projects/agora/)

[Janus](/projects/janus/)

[Praxis](/projects/praxis/)

[Prometheus](/projects/prometheus/)



### How You Can Help

- 💜 [Support our cause](/pages/donate.html) — Donations are tax-deductible. See the [Donor Summary](/pages/donor-summary/) for details.
- 🧠 Get involved — [Contact us](mailto:info@phronesisproject.org) to collaborate

> “It’s amazing what we can accomplish when no one needs to take credit.”
> — Ronald Reagan

### Paperwork
- [IRS Exemption Letter](/docs/irs-exemption-letter.pdf)
- [IRS EIN Letter](/docs/irs-ein-letter.pdf)
- [IRS Form 1023-EZ](/docs/1023-EZ.pdf)

- [Oregon Articles of Incorporation](docs/Articles-of-Incorporation.pdf)

- [Phronesis Initial Organizational Resolution](Signed%20docs.pdf)
- [Phronesis Bylaws](/docs/Phronesis-Bylaws.pdf)
- [Phronesis Conflict of Interest Policy](/docs/Phronesis-Conflict-of-Interest-Policy.pdf)



---

[View on GitHub](https://github.com/mcorning/phronesisproject.org)
